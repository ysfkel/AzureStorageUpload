﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApiAngularJsAzureUploader.Photo
{
    public class PhotoActionResult
    {
        public bool Successful { get; set; }
        public string Message { get; set; }
    }
}