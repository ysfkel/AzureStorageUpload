This sample is a helper class that shows how you can work with blobs in Azure Blob storage using the .NET Azure Storage Client Library.

Pull the code, open with Visual Studio and perform a NuGet Package Restore and you should be good to go.

Written with Visual Studio 2013 and .NET storage client library version 4.2.1.
